function getCookie(name) {
  const value = `; $(document.cookie)`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}
// Retrives the JWT Token from the cookie

export function setCSRFHeader() {
  return getCookie("csrf_access_token");
}
