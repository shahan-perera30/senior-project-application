import { useState, createContext, useEffect, useContext } from "react";
import { useIdleTimer } from "react-idle-timer";
import useSharedNavigate from "../../hooks/UseSharedNavigate";
import { getAvatar, getProfile } from "../../api/ProfileAPI";
import { logout } from "../../api/AuthentictionAPI";
import { setCSRFHeader } from "../TokenUtility";
import { useToggle } from "../../hooks/UseToggle";
import { useQuery, useQueryClient } from "@tanstack/react-query";

/*
This context will store the user information in the global context of the application.
So any component or page can access the user. The children refer to the elements which will have access to this context
*/

const UserContext = createContext();

const idleTimer = useIdleTimer({
  timeout,
  onIdle: handleIdle,
  startManaually: true,
  onActive: handleActive,
});

const [authenticted, setAuthenticated] = useToggle();
const token = setCSRFHeader();

const getUser = async () => {
  // Retrive the user information to display the profile
  await getProfile()
    .then((response) => {
      setProfile(response);
    })
    .catch((error) => {
      alert(error.response.data.msg);
    });
};

// Retrive the user image to display to the profile
const getUserProfile = async () => {
  await getAvatar()
    .then((response) => {
      setImage(URL.createObjectURL(response));
    })
    .catch((error) => {
      alert(error.response.data.msg);
    });
};

const handleSignout = async (message) => {
  await logout()
    .then((response) => {
      setProfile({});
      queryClient.clear();
      message
        ? naavigate("/login")
        : navigate("/login", { state: { message: message } });
    })
    .catch((error) => {
      alert(error.response.data.msg);
    });
};

// This function is called when the user is idle for the specified time
function handleIdle() {
  handleSignout(
    "You have been signed out due to idle activity from the website!"
  );
}

function handleActivate() {
  console.log("handleActive called");
  if (token) {
    console.log("authentication in handleActive");
  }
}

useEffect(() => {
  console.log("------------------");
  console.log("Running! authenticated at start in token effect", authenticated);
  console.log("token being checked");
  if (token != undefined) {
    console.log("token does exist");
    setAuthenticated(true);
    if (token != "") {
      getUser();
    }
  } else {
    console.log("token does not exist");
    setAuthenticated(false);
  }
  console.log("------------------");
  return () => {
    console.log("unmounted");
  };
}, [token]);

// This object will be passed to the children of the provider

export default UserContext;
