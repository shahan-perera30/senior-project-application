import React from "react";
import { setCSRFHeader } from "../TokenUtility";
import { Navigate, Outlet } from "react-router-dom";

const ProtectedRoutes = () => {
  // const [auth, setAuth] = useState(false);
  // const {authenticated} = setAuth();

  return (
    //Checks to see if the user is authenticated. If not, the user is redirected to the login page else the user proceeds to the Protected Route

    setCSRFHeader() !== undefined ? <Outlet /> : <Navigate to="/login" />
  );
};

export default ProtectedRoutes;
