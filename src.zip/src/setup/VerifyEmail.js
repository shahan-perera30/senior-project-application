import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import useSharedNavigate from "../hooks/UseSharedNavigate";
import { verifyEmail } from "../api/AuthenticationAPI";

function VerifyEmail() {
  const [status, setStatus] = useState("pending");
  const [email, setEmail] = useState("");
  const [token, setToken] = useState("");
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useSharedNavigate();

  useEffect(() => {
    const currentUrl = window.location.href;
    setSearchParams(new URLSearchParams(currentUrl.split("?")[1]));
  }, [setSearchParams]);

  useEffect(() => {
    setEmail(searchParams.get("email"));
    setToken(searchParams.get("token"));
  }, [searchParams]);

  useEffect(() => {
    async function verifyEmailAndRedirect() {
      if (email && token) {
        setStatus("verifying");
        try {
          await verifyEmail(email, token);
          alert("User is successfuly verified");
          setStatus("verified");
          navigate("/dashboard");
        } catch (error) {
          alert("Something went wrong!");
          setStatus("failed");
        }
      }
    }
    verifyEmailAndRedirect();
  }, [navigate, email, token]);

  if (status === "pending") {
    return (
      <div>
        Email Not Verified
        <div>Verifying email...</div>
      </div>
    );
  } else if (status === "verifying") {
    return <div>Verifying email...</div>;
  } else if (status === "verified") {
    return <div>Email verified! Redirecting to dashboard..</div>;
  } else if (status === "failed") {
    return <div>Failed</div>;
  }
}

export default VerifyEmail;
