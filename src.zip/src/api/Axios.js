//axios.js
import axios from "axios";
import useSharedNavigate from "../hooks/UseSharedNavigate";

const instance = axios.create();

instance.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response) {
      if (
        error.response.status === 401 &&
        error.response.data.sub_status === "expired_token"
      ) {
        // Handle 401 error here, for example redirect to login page
        const navigate = useSharedNavigate();
        navigate("/signout");
        return Promise.reject(error);
      } else {
        return Promise.reject(error);
      }
    } else {
      // Handle server down error here if there is no response
      const customError = new Error("Something went wrong");
      return Promise.reject(customError);
    }
  }
);

export default instance;
