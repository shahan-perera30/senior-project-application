import axios from "./Axios";
import { setCSRFHeader } from "../setup/TokenUtility";

const baseURL = "/user-controls";

/**
 * getProfile - a function that retrieves the user's profile data.
 * @returns {Object} user - the user's profile data
 * @throws {Error} error - if there is an error with the request
 */
export const getProfile = async () => {
  try {
    const response = await axios.get(`${baseURL}/profile`);
    return response.data.user;
  } catch (error) {
    throw error;
  }
};

/**
 * updateProfile - a function that updates the user's profile data.
 * @param {Object} data - the data to be updated
 * @returns {Object} response - the response from the server
 * @throws {Error} error - if there is an error with the request
 */
export const updateProfile = async (data) => {
  try {
    const response = await axios.put(`${baseURL}/profile`, data, {
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-TOKEN": setCSRFHeader(),
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * updateAvatar - a function that updates the user's avatar.
 * @param {FormData} formData - the form data containing the avatar image
 * @returns {Object} response - the response from the server
 * @throws {Error} error - if there is an error with the request
 */
export const updateAvatar = async (formData) => {
  try {
    const response = await axios.post(`${baseURL}/profile-avatar`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        "X-CSRF-TOKEN": setCSRFHeader(),
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

/**
 * getAvatar - a function that retrieves the user's avatar.
 * @returns {Object} response - the response from the server
 * @throws {Error} error - if there is an error with the request
 */
export const getAvatar = async () => {
  try {
    const response = await axios.get(`${baseURL}/profile-avatar`, {
      headers: {
        "X-CSRF-TOKEN": setCSRFHeader(),
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};
