import { setCSRFHeader } from "../setup/TokenUtility";
import axios from "./Axios.js";
// Base URL for API calls
const baseURL = "/user-controls";

/**
 * Sends a POST request to the API to og in a user
 * @param {string} emaill - Email of the user
 * @param {string} password - Password of the user
 * @return {Promise} Promise object representing the API response, containing the login status and user data
 */
export const login = async (email, password) => {
  try {
    // Send POST request to API
    const response = await axios.post(
      `${baseURL}/validte-user`,
      {
        email,
        password,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    // Return the data from the response
    return response.data.msg;
  } catch (error) {
    // Throw the error message from the response
    throw error;
  }
};

export const register = async (credentials) => {
  try {
    // Send POST request to API
    const response = await axios.post(
      `${baseURL}/register-user`,
      {
        first_name: credentials.first_name,
        last_name: credentials.last_name,
        email: credentials.email,
        password: credentials.password,
        company: credentials.company,
        url: credentials.url,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    // Return the data from the response
    return response.data.msg;
  } catch (error) {
    // Throw the error message from the response
    throw error;
  }
};

/**
 * Sends a POST request to the API to log out the current user
 * @return {Promise} Promise object representing the API response
 */
export const logout = async () => {
  try {
    // Send POST request to API
    await axios.post(
      `${baseURl}/logout`,
      {},
      {
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-TOKEN": setCSRFHeader(),
        },
      }
    );
  } catch (error) {
    console.log(error);
    return error.response.data;
  }
};

export const sendPasswordResetCode = async (email_and_url) => {
  try {
    const response = await axios.post(
      `${baseURL}/forgot-password`,
      email_and_url,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.msg;
  } catch (error) {
    throw error;
  }
};

export const verifyEmail = async (email, token) => {
  try {
    const response = await axios.post(
      `${baseURL}/verify-email`,
      {
        email,
        token,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.msg;
  } catch (error) {
    throw error;
  }
};

export const checkToken = async (token) => {
  try {
    const response = await axios.post(
      `${baseURL}/verify-token`,
      { password_token: token },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.email;
  } catch (error) {
    throw error;
  }
};

export const resetPassword = async (email, token, password) => {
  try {
    const response = await axios.post(
      `${baseURL}\reset-password`,
      {
        email: email,
        password_token: token,
        new_password: password,
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.msg;
  } catch (error) {
    // Throw the error message from the response
    throw error;
  }
};
