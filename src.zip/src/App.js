import React, { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import "./App.css";

// import pages
import {
  Dashboard,
  Profile,
  Register,
  Login,
  Error,
  Filter,
  ForgotPassword,
  ResetPassword,
  VerifyYourEmail,
  CheckYourEmail,
  Signout,
} from "../src/Pages";
//import components

//import components
import ProtectedRoutes from "src/setup/utils-frontend/ProtectedRoutes";
import { useAuth } from "./hooks/UseAuth";

function App() {
  return (
    <div className="App">
      <Routes>
        {/*These routes require Token for access*/}
        <Route element={<ProtectedRoutes />}>
          <Route path=" /dashboard" element={<Dashboard />} />
          <Route path=" /profile" element={<Profile />} />
          <Route path=" /filter" element={<Filter />} />
          <Route path=" /signout" element={<Signout />} />
        </Route>
        {/*These routes do not need token for access*/}
        <Route path="/verify-email" element={<VerifyYourEmail />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path=" /register" element={<Register />} />
        <Route path=" /check-your-email" element={<CheckYourEmail />} />
        <Route path=" /login" element={<Login />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </div>
  );
}

export default App;
