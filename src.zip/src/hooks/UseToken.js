import { setCSRFHeader } from "../setup/TokenUtility";
import { useEffect, useState } from "react";

export const useToken = () => {
  //Retrives the JWT Token from the cookie
  const [token, setToken] = useState(setCSRFHeader());

  useEffect(() => {
    setToken(setCSRFHeader());
  }, []);

  return token;
};
