import { useNavigate } from "react-router-dom";

/**
 * Custom hook to share the useNavigate hook across multiple components
 * @returns {function} useNavigte - a hook that allows navigation to different routes
 */
const useSharedNavigate = () => {
  return useNavigate();
};

export default useSharedNavigate;
