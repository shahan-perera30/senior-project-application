import userContext from "src/setup/context/UserContext";
import { useContext } from "react";
/* 
    This hook is used to get the user data from the userContext
    and returns it to the component that calls it.
    @returns {Object} use the user dat from the userContext
*/
export const useAuth = () => {
  return useContext(userContext);
};
