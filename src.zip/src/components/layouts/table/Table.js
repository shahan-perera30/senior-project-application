import React from "react";

const Table = ({}) => {
  return (
    <div className="table">
      <table className="table-container">
        <tbody className="table-body"></tbody>
      </table>
    </div>
  );
};

export default Table;
